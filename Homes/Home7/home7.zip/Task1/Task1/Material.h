enum class Material {Metal, Plastic};
